export const game = {
  playerName: 'Anonimus',
  totalScore: 0,
  level: 0,
  isGameOver: false,

};



// export const game = {
//   playerName: "Noname",
//   totalScore: 0,
//   level: 0,
//   isGameOver: false,
// };