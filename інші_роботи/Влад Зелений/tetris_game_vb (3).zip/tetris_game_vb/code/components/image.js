export function Image(src,clasName,alt) {
  return`<img class="${clasName}" src="./image/icons-svg/${src}" alt="${alt}">`
}