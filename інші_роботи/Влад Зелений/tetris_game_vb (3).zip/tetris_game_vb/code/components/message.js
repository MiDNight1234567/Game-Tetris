// Функція створення компонента повідомлення.
export function Message(message) {
	return `<div class="message">
  <h2>${message}</h2>
  </div>`;
}
